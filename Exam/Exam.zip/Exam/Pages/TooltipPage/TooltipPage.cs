﻿using System;
using System.Collections.Generic;
using System.Text;
using OpenQA.Selenium;

namespace Exam.Pages.TooltipPage
{
    public partial class TooltipPage : BasePage
    {
        public TooltipPage(IWebDriver driver) : base(driver)
        {
        }

        public void GoToTooltipPage()
        {
            TooltipLink.Click();
        }

        public void ClickInput()
        {
            InputEl.Click();
        }

        public string GetTooltipText()
        {
            return InputEl.GetAttribute("title");
        }

        public bool isTooltipVisible()
        {
            return GetTooltipText().Length == 0;
        }

    }
}
